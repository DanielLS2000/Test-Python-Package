def bye_world():
    print("Bye World")