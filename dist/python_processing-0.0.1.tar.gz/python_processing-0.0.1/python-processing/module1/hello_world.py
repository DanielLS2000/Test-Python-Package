def hello_world():
    print("hello_world")