# package_name

Description. 
The package python-processing is used to:
	- 
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install python-processing

```bash
pip install python-processing
```

## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
```

## Author
Daniel

## License
[MIT](https://choosealicense.com/licenses/mit/)